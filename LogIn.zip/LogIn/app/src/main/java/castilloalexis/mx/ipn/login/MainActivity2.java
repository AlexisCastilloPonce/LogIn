package castilloalexis.mx.ipn.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView muestra;
    String nombreUsu;
    String contraUsu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        muestra = (TextView)findViewById(R.id.muestraUsuario);
        Bundle trae = new Bundle();
        trae = this.getIntent().getExtras();
        nombreUsu = trae.getString("usuario");
        contraUsu = trae.getString("contra");
        if(nombreUsu.equals("Alexis") && contraUsu.equals("contra123")){
            muestra.setText("Usuario: " + nombreUsu);
        }else{
            Intent sale = new Intent(this, MainActivity.class);
            startActivity(sale);
        }

    }
}
