package castilloalexis.mx.ipn.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nombreUsu;
    EditText contra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombreUsu = (EditText)findViewById(R.id.nomUsuario);
        contra = (EditText)findViewById(R.id.contrasenia);
    }

    public void IniciaSesion(View v){
        Intent entra = new Intent(this, MainActivity2.class);
        Bundle guardar = new Bundle();
        guardar.putString("usuario", nombreUsu.getText().toString().trim());
        guardar.putString("contra", contra.getText().toString().trim());
        entra.putExtras(guardar);
        finish();
        startActivity(entra);
    }

    public void BorrarTexto(View v){
        nombreUsu.setText("");
    }

    public void BorrarContra(View v){
        contra.setText("");
    }
}
